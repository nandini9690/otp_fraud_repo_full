MODEL_PATH = 'models/fraud_model.pkl'
FEATURE_COLUMNS = ['typing_match', 'motion_match', 'switch_delay_ms', 'entry_mode_code']
