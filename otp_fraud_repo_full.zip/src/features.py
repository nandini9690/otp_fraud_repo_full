def encode_entry_mode(series):
    mapping = {'Manual typing': 0, 'Auto fill': 1, 'Copy paste': 2}
    return series.map(mapping).fillna(3).astype(int)


def build_features(df):
    out = df.copy()
    out['entry_mode_code'] = encode_entry_mode(out['entry_mode'])
    return out
