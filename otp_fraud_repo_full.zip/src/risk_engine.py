from dataclasses import dataclass

@dataclass
class SessionInput:
    entry_mode: str
    typing_match: int
    motion_match: int
    switch_delay_ms: int


def evaluate_session(session: SessionInput):
    score = (session.typing_match * 0.4) + (session.motion_match * 0.35)
    delay_component = max(0, 100 - abs(session.switch_delay_ms - 1200) / 20)
    score = score + (delay_component * 0.25)

    if session.entry_mode == 'Copy paste':
        score -= 18
    elif session.entry_mode == 'Auto fill':
        score -= 8

    score = max(0, min(100, round(score)))
    risk = 100 - score

    if risk > 45:
        decision = 'Block'
    elif risk > 25:
        decision = 'Challenge'
    else:
        decision = 'Approve'

    reasons = []
    if session.entry_mode != 'Manual typing':
        reasons.append('Unusual OTP entry mode')
    if session.typing_match < 70:
        reasons.append('Typing pattern mismatch')
    if session.motion_match < 70:
        reasons.append('Motion pattern mismatch')
    if abs(session.switch_delay_ms - 1200) > 900:
        reasons.append('Abnormal app-switch latency')

    return {
        'behavior_similarity': score,
        'risk_score': risk,
        'decision': decision,
        'reasons': reasons or ['Session matched the baseline profile']
    }
