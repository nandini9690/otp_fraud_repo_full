import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from src.data import load_session_data
from src.features import build_features
from src.utils import save_model
from src.config import MODEL_PATH


def main():
    df = load_session_data('sample_data/sessions.csv')
    df = build_features(df)
    x = df[['typing_match', 'motion_match', 'switch_delay_ms', 'entry_mode_code']]
    y = df['label']
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(x, y)
    save_model(model, MODEL_PATH)
    print('Model saved to ' + MODEL_PATH)

if __name__ == '__main__':
    main()
