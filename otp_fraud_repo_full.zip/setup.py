from setuptools import setup, find_packages

setup(
    name='otp-behavioral-fraud-prototype',
    version='0.1.0',
    packages=find_packages(),
)
