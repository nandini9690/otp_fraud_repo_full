from src.risk_engine import SessionInput, evaluate_session


def test_manual_typing_low_risk():
    result = evaluate_session(SessionInput('Manual typing', 90, 85, 1200))
    assert result['decision'] in ['Approve', 'Challenge']


def test_copy_paste_higher_risk():
    result = evaluate_session(SessionInput('Copy paste', 40, 45, 2500))
    assert result['decision'] == 'Block'
