import json
import streamlit as st
from src.risk_engine import SessionInput, evaluate_session

st.set_page_config(page_title='OTP Fraud Prototype', page_icon='🔐', layout='wide')

st.title('OTP Behavioral Fraud Detection Prototype')
st.write('A demo risk engine for OTP sessions using typing rhythm, motion, and latency signals.')

with open('sample_user_profile.json', 'r', encoding='utf-8') as f:
    baseline = json.load(f)

col1, col2 = st.columns(2)
with col1:
    entry_mode = st.selectbox('OTP Entry Mode', ['Manual typing', 'Copy paste', 'Auto fill'])
    typing_match = st.slider('Typing Rhythm Match', 0, 100, baseline['typing_match_baseline'])
    motion_match = st.slider('Motion Match', 0, 100, baseline['motion_match_baseline'])
    switch_delay_ms = st.number_input('App Switch Delay ms', min_value=0, max_value=10000, value=baseline['expected_switch_delay_ms'])
    run = st.button('Evaluate Transaction')

with col2:
    st.subheader('Decision Output')
    if run:
        result = evaluate_session(SessionInput(entry_mode, typing_match, motion_match, switch_delay_ms))
        st.metric('Behavior Similarity', str(result['behavior_similarity']) + '/100')
        st.metric('Risk Score', str(result['risk_score']) + '/100')
        st.metric('Decision', result['decision'])
        st.write('Reasons')
        for reason in result['reasons']:
            st.write('- ' + reason)
    else:
        st.info('Adjust the session inputs and click Evaluate Transaction.')
