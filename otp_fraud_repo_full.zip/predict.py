import argparse
import pandas as pd
from src.features import build_features
from src.utils import load_model
from src.config import MODEL_PATH


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', required=True)
    args = parser.parse_args()

    model = load_model(MODEL_PATH)
    df = pd.read_csv(args.input)
    df = build_features(df)
    preds = model.predict(df[['typing_match', 'motion_match', 'switch_delay_ms', 'entry_mode_code']])
    df['prediction'] = preds
    print(df[['entry_mode', 'typing_match', 'motion_match', 'switch_delay_ms', 'prediction']].to_string(index=False))

if __name__ == '__main__':
    main()
