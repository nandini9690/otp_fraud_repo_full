# OTP Behavioral Fraud Detection Prototype

[![CI](https://github.com/your-username/otp-fraud-prototype/actions/workflows/ci.yml/badge.svg)](https://github.com/your-username/otp-fraud-prototype/actions/workflows/ci.yml)

A GitHub-ready Streamlit + ML prototype for detecting OTP fraud using behavioral biometrics.

## Overview

This demo evaluates OTP sessions using behavioral signals such as typing rhythm, motion consistency, and app-switch latency, then returns a fraud risk decision.

## Architecture

```text
User input -> Streamlit app -> risk engine -> rule-based decision
                        \-> training pipeline -> model.pkl
```

## Features

The prototype includes a simple Streamlit UI, a reusable risk engine, a basic training script, a prediction script, and automated tests.

## Project structure

```text
otp_fraud_repo_full/
├── app.py
├── main.py
├── train.py
├── predict.py
├── requirements.txt
├── pyproject.toml
├── setup.py
├── Dockerfile
├── .gitignore
├── LICENSE
├── .github/workflows/ci.yml
├── sample_data/sessions.csv
├── models/.gitkeep
├── src/
│   ├── __init__.py
│   ├── config.py
│   ├── data.py
│   ├── features.py
│   ├── risk_engine.py
│   └── utils.py
└── tests/
    └── test_risk_engine.py
```

## Local setup

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Train the model

```bash
python train.py
```

## Make a prediction from CSV

```bash
python predict.py --input sample_data/sessions.csv
```

## Run tests

```bash
pytest -q
```

## Docker

```bash
docker build -t otp-fraud-prototype .
docker run -p 8501:8501 otp-fraud-prototype
```

## Deployment notes

In production, behavioral signals should be collected with explicit consent, encrypted, and processed as part of a risk-based authentication flow rather than as the only security control.
